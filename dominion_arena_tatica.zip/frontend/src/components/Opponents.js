export default function Opponents({ opponents, currentUsername }) {
  if (!opponents || opponents.length === 0) {
    return (
      <div className="card">
        <p style={{ color: '#95a5a6' }}>Nenhum opositor ainda</p>
      </div>
    );
  }

  return (
    <div>
      {opponents.map((opponent) => (
        <div key={opponent.playerId} className="card" style={{ marginBottom: '10px' }}>
          <h4>{opponent.username}</h4>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', fontSize: '14px' }}>
            <div>
              <span style={{ color: '#95a5a6' }}>Vidas:</span>
              <br />
              <span style={{ fontSize: '18px', color: '#e74c3c', fontWeight: 'bold' }}>{opponent.life}</span>
            </div>
            <div>
              <span style={{ color: '#95a5a6' }}>Ouro:</span>
              <br />
              <span style={{ fontSize: '18px', color: '#f39c12', fontWeight: 'bold' }}>{opponent.gold}</span>
            </div>
            <div>
              <span style={{ color: '#95a5a6' }}>Dados:</span>
              <br />
              <span style={{ fontSize: '18px', color: '#3498db', fontWeight: 'bold' }}>{opponent.dice}</span>
            </div>
            <div>
              <span style={{ color: '#95a5a6' }}>Mão:</span>
              <br />
              <span style={{ fontSize: '18px', fontWeight: 'bold' }}>{opponent.hand?.length || 0}/5</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
