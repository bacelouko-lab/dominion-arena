import { getSocket } from '../lib/socket';
import Card from './Card';

export default function Shop({ shop, playerGold, gameId }) {
  const socket = getSocket();

  const handleBuyCard = (cardInstanceId, cardCost) => {
    if (playerGold < cardCost) {
      alert('Ouro insuficiente!');
      return;
    }
    socket.emit('buy-card', { cardInstanceId });
  };

  return (
    <div className="card">
      <h3>🏪 Loja</h3>
      {shop.length === 0 ? (
        <p style={{ color: '#95a5a6' }}>Nenhuma carta na loja</p>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))', gap: '10px' }}>
          {shop.map((card) => (
            <div key={card.instanceId}>
              <Card card={card} />
              <button
                onClick={() => handleBuyCard(card.instanceId, card.custo)}
                style={{
                  width: '100%',
                  marginTop: '5px',
                  fontSize: '12px',
                  background: playerGold >= card.custo ? '#27ae60' : '#7f8c8d'
                }}
                disabled={playerGold < card.custo}
              >
                Comprar ({card.custo})
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
