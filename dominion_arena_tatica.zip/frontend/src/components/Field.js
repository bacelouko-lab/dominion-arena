import Card from './Card';

export default function Field({ field, gameId }) {
  if (!field) return null;

  return (
    <div className="card">
      <h3>⚔️ Campo</h3>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: '10px' }}>
        {Array.from({ length: 6 }).map((_, index) => (
          <div
            key={index}
            style={{
              background: '#34495e',
              border: '2px dashed #7f8c8d',
              borderRadius: '8px',
              padding: '10px',
              minHeight: '150px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center'
            }}
          >
            {field[index] ? (
              <Card card={field[index]} />
            ) : (
              <div style={{ color: '#7f8c8d', fontSize: '12px', textAlign: 'center' }}>Posição {index}</div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
