import { getSocket } from '../lib/socket';
import Card from './Card';

export default function Hand({ hand, gameId }) {
  const socket = getSocket();

  const handlePlaceCard = (cardIndex, fieldPosition) => {
    socket.emit('place-card', { cardIndex, fieldPosition });
  };

  if (!hand || hand.length === 0) {
    return (
      <div className="card">
        <h3>✋ Mão</h3>
        <p style={{ color: '#95a5a6' }}>Sua mão está vazia</p>
      </div>
    );
  }

  return (
    <div className="card">
      <h3>✋ Mão ({hand.length}/5)</h3>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(100px, 1fr))', gap: '10px' }}>
        {hand.map((card, index) => (
          <div key={index}>
            <Card
              card={card}
              onClick={() => {
                const position = prompt('Qual posição no campo? (0-5)');
                if (position !== null && position >= 0 && position <= 5) {
                  handlePlaceCard(index, parseInt(position));
                }
              }}
            />
            <button
              onClick={() => {
                const position = prompt('Qual posição no campo? (0-5)');
                if (position !== null && position >= 0 && position <= 5) {
                  handlePlaceCard(index, parseInt(position));
                }
              }}
              style={{ width: '100%', marginTop: '5px', fontSize: '12px' }}
            >
              Colocar no Campo
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
