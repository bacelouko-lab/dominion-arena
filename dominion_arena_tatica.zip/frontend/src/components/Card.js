export default function Card({ card, onClick, style = {} }) {
  if (!card) return null;

  const colors = {
    'Guerreiro': '#e74c3c',
    'Mago': '#9b59b6',
    'Ladino': '#f39c12',
    'Suporte': '#27ae60',
    'Monstro': '#c0392b',
    'Mercador': '#f39c12',
    'Dragão': '#e67e22'
  };

  const cardColor = colors[card.classe] || '#3498db';

  return (
    <div
      onClick={onClick}
      style={{
        background: '#2c3e50',
        border: `2px solid ${cardColor}`,
        borderRadius: '8px',
        padding: '10px',
        cursor: onClick ? 'pointer' : 'default',
        transition: 'transform 0.2s',
        ...style
      }}
      onMouseEnter={(e) => onClick && (e.target.style.transform = 'scale(1.05)')}
      onMouseLeave={(e) => onClick && (e.target.style.transform = 'scale(1)')}
    >
      <div style={{ fontSize: '12px', fontWeight: 'bold', marginBottom: '5px' }}>{card.nome}</div>
      <div style={{ fontSize: '10px', color: '#bdc3c7', marginBottom: '5px' }}>
        {card.regiao} • {card.classe}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '14px', fontWeight: 'bold', marginBottom: '5px' }}>
        <span style={{ color: '#e74c3c' }}>ATK {card.atk}</span>
        <span style={{ color: '#3498db' }}>DEF {card.def}</span>
      </div>
      <div style={{ fontSize: '9px', color: '#95a5a6', lineHeight: '1.2' }}>
        {card.habilidade_descricao}
      </div>
      {card.custo !== undefined && (
        <div style={{ marginTop: '5px', fontSize: '11px', color: '#f39c12', fontWeight: 'bold' }}>
          Custo: {card.custo}
        </div>
      )}
    </div>
  );
}
