export default function GamePhase({ phase, turn }) {
  const phaseNames = {
    'roll': '🎲 Fase de Rolar',
    'buy': '🛒 Fase de Compra',
    'combat': '⚔️ Fase de Combate',
    'end': '🏁 Fim do Turno'
  };

  const phaseEmojis = {
    'roll': '🎲',
    'buy': '🛒',
    'combat': '⚔️',
    'end': '🏁'
  };

  return (
    <div className="card" style={{ background: '#34495e', marginBottom: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2>{phaseNames[phase] || 'Desconhecida'}</h2>
          <p style={{ color: '#95a5a6' }}>Turno {turn}</p>
        </div>
        <div style={{ fontSize: '48px' }}>{phaseEmojis[phase]}</div>
      </div>
    </div>
  );
}
