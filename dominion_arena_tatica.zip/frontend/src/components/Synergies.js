export default function Synergies({ synergies }) {
  if (!synergies || (Object.keys(synergies.regions || {}).length === 0 && Object.keys(synergies.classes || {}).length === 0)) {
    return (
      <div className="card">
        <h3>🔗 Sinergias</h3>
        <p style={{ color: '#95a5a6' }}>Nenhuma sinergia ativa</p>
      </div>
    );
  }

  return (
    <div className="card">
      <h3>🔗 Sinergias Ativas</h3>
      {synergies.regions && Object.keys(synergies.regions).length > 0 && (
        <div style={{ marginBottom: '15px' }}>
          <h4 style={{ marginBottom: '10px' }}>Regiões</h4>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
            {Object.entries(synergies.regions).map(([region, count]) => count > 0 && (
              <div key={region} style={{ background: '#34495e', padding: '10px', borderRadius: '4px' }}>
                <div style={{ fontSize: '12px', color: '#95a5a6' }}>{region}</div>
                <div style={{ fontSize: '18px', fontWeight: 'bold', color: '#f39c12' }}>x{count}</div>
              </div>
            ))}
          </div>
        </div>
      )}
      {synergies.classes && Object.keys(synergies.classes).length > 0 && (
        <div>
          <h4 style={{ marginBottom: '10px' }}>Classes</h4>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
            {Object.entries(synergies.classes).map(([cls, count]) => count > 0 && (
              <div key={cls} style={{ background: '#34495e', padding: '10px', borderRadius: '4px' }}>
                <div style={{ fontSize: '12px', color: '#95a5a6' }}>{cls}</div>
                <div style={{ fontSize: '18px', fontWeight: 'bold', color: '#3498db' }}>x{count}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
