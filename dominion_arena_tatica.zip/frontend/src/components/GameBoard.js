import { useState, useEffect } from 'react';
import { getSocket } from '../lib/socket';
import PlayerStats from './PlayerStats';
import Shop from './Shop';
import Hand from './Hand';
import Field from './Field';
import GamePhase from './GamePhase';
import Synergies from './Synergies';
import Opponents from './Opponents';

export default function GameBoard({ gameState, gameId, username }) {
  const socket = getSocket();
  const [players, setPlayers] = useState(gameState?.players || []);
  const [shop, setShop] = useState(gameState?.shop || []);
  const [phase, setPhase] = useState(gameState?.phase || 'roll');
  const [turn, setTurn] = useState(gameState?.turn || 0);
  const [currentPlayer, setCurrentPlayer] = useState(null);
  const [synergies, setSynergies] = useState({});

  useEffect(() => {
    if (!socket) return;

    // Get current player
    const player = players.find(p => p.username === username);
    if (player) setCurrentPlayer(player);

    socket.on('player-joined', ({ players }) => {
      setPlayers(players);
    });

    socket.on('player-left', ({ playerId }) => {
      setPlayers(prev => prev.filter(p => p.playerId !== playerId));
    });

    socket.on('dice-rolled', ({ playerId, rolls, totalGold }) => {
      setPlayers(prev => prev.map(p => p.playerId === playerId ? { ...p, gold: totalGold } : p));
    });

    socket.on('shop-generated', ({ shop }) => {
      setShop(shop);
    });

    socket.on('card-bought', ({ playerId, hand, gold }) => {
      setPlayers(prev => prev.map(p => p.playerId === playerId ? { ...p, hand, gold } : p));
      setShop(prev => prev.filter(c => c.instanceId)); // Update shop
    });

    socket.on('card-placed', ({ playerId, field, hand }) => {
      setPlayers(prev => prev.map(p => p.playerId === playerId ? { ...p, field, hand } : p));
    });

    socket.on('phase-changed', ({ phase, turn }) => {
      setPhase(phase);
      setTurn(turn);
    });

    socket.on('evolution-checked', ({ playerId, hand }) => {
      setPlayers(prev => prev.map(p => p.playerId === playerId ? { ...p, hand } : p));
    });

    socket.on('synergies-calculated', (data) => {
      setSynergies(data);
    });

    socket.on('combat-resolved', ({ attacker, defender, netDamage }) => {
      setPlayers(prev => prev.map(p => {
        if (p.playerId === defender) {
          return { ...p, life: Math.max(0, p.life - netDamage) };
        }
        return p;
      }));
    });

    return () => {
      socket.off('player-joined');
      socket.off('player-left');
      socket.off('dice-rolled');
      socket.off('shop-generated');
      socket.off('card-bought');
      socket.off('card-placed');
      socket.off('phase-changed');
      socket.off('evolution-checked');
      socket.off('synergies-calculated');
      socket.off('combat-resolved');
    };
  }, [socket, players, username]);

  if (!currentPlayer) {
    return <div>Carregando jogador...</div>;
  }

  const opponents = players.filter(p => p.username !== username);

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr 1fr', gap: '20px' }}>
      {/* Left Sidebar - Opponents */}
      <div style={{ maxHeight: '90vh', overflowY: 'auto' }}>
        <h3>Opositores</h3>
        <Opponents opponents={opponents} currentUsername={username} />
      </div>

      {/* Main Game Area */}
      <div style={{ maxHeight: '90vh', overflowY: 'auto' }}>
        <GamePhase phase={phase} turn={turn} />
        <PlayerStats player={currentPlayer} />
        <Shop shop={shop} playerGold={currentPlayer.gold} gameId={gameId} />
        <Field field={currentPlayer.field} gameId={gameId} />
        <Hand hand={currentPlayer.hand} gameId={gameId} />
      </div>

      {/* Right Sidebar - Controls and Synergies */}
      <div style={{ maxHeight: '90vh', overflowY: 'auto' }}>
        <div className="card">
          <h3>Controles</h3>
          <button onClick={() => socket.emit('roll-dice')} style={{ width: '100%', marginBottom: '10px' }}>
            🎲 Rolar Dados
          </button>
          <button onClick={() => socket.emit('generate-shop')} style={{ width: '100%', marginBottom: '10px' }}>
            🎉 Gerar Loja
          </button>
          <button onClick={() => socket.emit('check-evolution')} style={{ width: '100%', marginBottom: '10px' }}>
            ✨ Verificar Evolução
          </button>
          <button onClick={() => socket.emit('next-phase')} style={{ width: '100%', marginBottom: '10px' }}>
            ➡️ Próxima Fase
          </button>
          <button onClick={() => socket.emit('calculate-synergies')} style={{ width: '100%' }}>
            🔍 Calcular Sinergias
          </button>
        </div>

        <Synergies synergies={synergies} />
      </div>
    </div>
  );
}
