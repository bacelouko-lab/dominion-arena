import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { initSocket, getSocket } from '../../lib/socket';
import GameBoard from '../../components/GameBoard';

export default function GamePage() {
  const router = useRouter();
  const { gameId, username } = router.query;
  const [gameState, setGameState] = useState(null);
  const [playerState, setPlayerState] = useState(null);
  const [error, setError] = useState('');
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    if (!gameId || !username) return;

    const socket = initSocket();

    socket.on('connect', () => {
      setConnected(true);
      socket.emit('join-game', { gameId, username });
    });

    socket.on('game-state', (state) => {
      setGameState(state);
    });

    socket.on('player-joined', ({ players }) => {
      setGameState((prev) => prev ? { ...prev, players } : null);
    });

    socket.on('error', (msg) => {
      setError(msg);
    });

    socket.on('disconnect', () => {
      setConnected(false);
    });

    return () => {
      // Don't disconnect on unmount - keep connection alive
    };
  }, [gameId, username]);

  if (!gameId || !username) {
    return <div className="flex-center h-full" style={{ minHeight: '100vh' }}>Carregando...</div>;
  }

  if (!connected) {
    return (
      <div className="flex-col flex-center h-full" style={{ minHeight: '100vh' }}>
        <div className="card">
          <p>Conectando ao servidor...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex-col flex-center h-full" style={{ minHeight: '100vh' }}>
        <div className="card">
          <div className="error">{error}</div>
          <button onClick={() => router.push('/')}>Voltar ao Menu</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', padding: '20px' }}>
      <div style={{ marginBottom: '10px' }}>
        <h2>Sala: {gameId.slice(0, 8)}</h2>
        <p>Jogador: {username}</p>
      </div>
      {gameState ? <GameBoard gameState={gameState} gameId={gameId} username={username} /> : <div>Carregando jogo...</div>}
    </div>
  );
}
