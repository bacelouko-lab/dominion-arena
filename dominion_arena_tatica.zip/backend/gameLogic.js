const cardsData = require('../dominion_cards.json');

class GameLogic {
  constructor(gameId) {
    this.gameId = gameId;
    this.players = {};
    this.currentPlayer = 0;
    this.phase = 'roll'; // roll, buy, combat
    this.turn = 0;
    this.shop = [];
  }

  addPlayer(playerId, username) {
    this.players[playerId] = {
      playerId,
      username,
      life: 20,
      gold: 0,
      dice: 1,
      hand: [],
      field: [],
      deck: [],
      discard: [],
      synergies: { regions: {}, classes: {} }
    };
  }

  // Roll dice and generate gold
  rollDice(playerId) {
    const player = this.players[playerId];
    if (!player) return { error: 'Player not found' };

    const diceCount = Math.min(player.dice, 3);
    let totalGold = 0;
    const rolls = [];

    for (let i = 0; i < diceCount; i++) {
      const roll = Math.floor(Math.random() * 6) + 1;
      rolls.push(roll);
      totalGold += roll;
    }

    player.gold += totalGold;
    return { gold: totalGold, rolls, totalGold: player.gold };
  }

  // Generate random shop
  generateShop() {
    const shopSize = 6;
    this.shop = [];

    for (let i = 0; i < shopSize; i++) {
      const randomCard = cardsData[Math.floor(Math.random() * cardsData.length)];
      this.shop.push({
        ...randomCard,
        instanceId: `${randomCard.id}-${Math.random()}`
      });
    }

    return this.shop;
  }

  // Buy card from shop
  buyCard(playerId, cardInstanceId) {
    const player = this.players[playerId];
    if (!player) return { error: 'Player not found' };

    const shopCardIndex = this.shop.findIndex(c => c.instanceId === cardInstanceId);
    if (shopCardIndex === -1) return { error: 'Card not found in shop' };

    const card = this.shop[shopCardIndex];
    if (player.gold < card.custo) return { error: 'Not enough gold' };

    if (player.hand.length >= 5) return { error: 'Hand is full' };

    player.gold -= card.custo;
    player.hand.push(card);

    return { success: true, hand: player.hand };
  }

  // Check and apply evolution (2 identical cards = 1 evolved)
  checkEvolution(playerId) {
    const player = this.players[playerId];
    const evolution = {};

    for (const card of player.hand) {
      evolution[card.id] = (evolution[card.id] || 0) + 1;
    }

    // Evolve cards
    for (const cardId in evolution) {
      if (evolution[cardId] >= 2) {
        const cardIndex = player.hand.findIndex(c => c.id == cardId);
        if (cardIndex !== -1) {
          const card = player.hand[cardIndex];
          const evolved = {
            ...card,
            nome: `${card.nome} (Evoluído)`,
            atk: Math.floor(card.atk * 1.3),
            def: Math.floor(card.def * 1.3),
            isEvolved: true
          };
          player.hand.splice(cardIndex, 2, evolved);
        }
      }
    }

    return player.hand;
  }

  // Place card in field
  placeCard(playerId, cardIndex, fieldPosition) {
    const player = this.players[playerId];
    if (!player) return { error: 'Player not found' };

    if (player.field.length >= 6) return { error: 'Field is full' };
    if (cardIndex >= player.hand.length) return { error: 'Invalid card' };

    const card = player.hand.splice(cardIndex, 1)[0];
    player.field[fieldPosition] = card;

    return { success: true, field: player.field, hand: player.hand };
  }

  // Calculate combat between two players
  calculateCombat(attacker, defender) {
    const attackerDamage = this.calculateFieldDamage(attacker.field);
    const defenderDamage = this.calculateFieldDamage(defender.field);

    const damage = Math.max(0, attackerDamage - defenderDamage);
    defender.life -= damage;

    return {
      attacker: { damage: attackerDamage, life: attacker.life },
      defender: { damage: defenderDamage, life: Math.max(0, defender.life) },
      netDamage: damage
    };
  }

  // Calculate total damage from field
  calculateFieldDamage(field) {
    return field.reduce((total, card) => {
      if (card) return total + (card.atk || 0);
      return total;
    }, 0);
  }

  // Calculate synergies
  calculateSynergies(playerId) {
    const player = this.players[playerId];
    const synergies = { regions: {}, classes: {} };

    const allCards = [...player.hand, ...player.field.filter(c => c)];

    for (const card of allCards) {
      synergies.regions[card.regiao] = (synergies.regions[card.regiao] || 0) + 1;
      synergies.classes[card.classe] = (synergies.classes[card.classe] || 0) + 1;
    }

    player.synergies = synergies;
    return synergies;
  }

  // Get player state
  getPlayerState(playerId) {
    return this.players[playerId] || null;
  }

  // Get game state
  getGameState() {
    return {
      gameId: this.gameId,
      phase: this.phase,
      turn: this.turn,
      shop: this.shop,
      players: Object.values(this.players)
    };
  }

  // Next phase
  nextPhase() {
    const phases = ['roll', 'buy', 'combat', 'end'];
    const currentIndex = phases.indexOf(this.phase);
    this.phase = phases[(currentIndex + 1) % phases.length];

    if (this.phase === 'roll') {
      this.turn++;
      // Reset gold for next turn
      for (const playerId in this.players) {
        this.players[playerId].gold = 0;
      }
    }

    return this.phase;
  }
}

module.exports = GameLogic;
