const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const GameLogic = require('./gameLogic');
const { pool, initDatabase } = require('./database');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    methods: ['GET', 'POST']
  }
});

app.use(cors());
app.use(express.json());

// Game storage
const games = new Map();
const playerSockets = new Map();

// Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

app.post('/api/games', (req, res) => {
  const gameId = uuidv4();
  const gameName = req.body.name || `Game ${gameId.slice(0, 8)}`;
  
  const game = new GameLogic(gameId);
  games.set(gameId, game);
  
  res.json({ gameId, gameName });
});

app.get('/api/games/:gameId', (req, res) => {
  const game = games.get(req.params.gameId);
  if (!game) return res.status(404).json({ error: 'Game not found' });
  
  res.json(game.getGameState());
});

// Socket.io events
io.on('connection', (socket) => {
  console.log(`User connected: ${socket.id}`);

  // Join game
  socket.on('join-game', ({ gameId, username }) => {
    const game = games.get(gameId);
    if (!game) {
      socket.emit('error', 'Game not found');
      return;
    }

    const playerId = uuidv4();
    game.addPlayer(playerId, username);
    playerSockets.set(playerId, socket.id);

    socket.join(gameId);
    socket.gameId = gameId;
    socket.playerId = playerId;

    // Send initial game state
    socket.emit('game-state', game.getGameState());
    io.to(gameId).emit('player-joined', { playerId, username, players: Object.values(game.players) });
  });

  // Roll dice
  socket.on('roll-dice', () => {
    const game = games.get(socket.gameId);
    if (!game) return;

    const result = game.rollDice(socket.playerId);
    io.to(socket.gameId).emit('dice-rolled', { playerId: socket.playerId, ...result });
  });

  // Generate shop
  socket.on('generate-shop', () => {
    const game = games.get(socket.gameId);
    if (!game) return;

    const shop = game.generateShop();
    io.to(socket.gameId).emit('shop-generated', { shop });
  });

  // Buy card
  socket.on('buy-card', ({ cardInstanceId }) => {
    const game = games.get(socket.gameId);
    if (!game) return;

    const result = game.buyCard(socket.playerId, cardInstanceId);
    if (result.error) {
      socket.emit('buy-error', result.error);
    } else {
      const playerState = game.getPlayerState(socket.playerId);
      io.to(socket.gameId).emit('card-bought', { playerId: socket.playerId, hand: playerState.hand, gold: playerState.gold });
    }
  });

  // Check evolution
  socket.on('check-evolution', () => {
    const game = games.get(socket.gameId);
    if (!game) return;

    const hand = game.checkEvolution(socket.playerId);
    const playerState = game.getPlayerState(socket.playerId);
    io.to(socket.gameId).emit('evolution-checked', { playerId: socket.playerId, hand });
  });

  // Place card
  socket.on('place-card', ({ cardIndex, fieldPosition }) => {
    const game = games.get(socket.gameId);
    if (!game) return;

    const result = game.placeCard(socket.playerId, cardIndex, fieldPosition);
    if (result.error) {
      socket.emit('place-error', result.error);
    } else {
      const playerState = game.getPlayerState(socket.playerId);
      io.to(socket.gameId).emit('card-placed', { playerId: socket.playerId, field: playerState.field, hand: playerState.hand });
    }
  });

  // Calculate synergies
  socket.on('calculate-synergies', () => {
    const game = games.get(socket.gameId);
    if (!game) return;

    const synergies = game.calculateSynergies(socket.playerId);
    socket.emit('synergies-calculated', synergies);
  });

  // Next phase
  socket.on('next-phase', () => {
    const game = games.get(socket.gameId);
    if (!game) return;

    const phase = game.nextPhase();
    io.to(socket.gameId).emit('phase-changed', { phase, turn: game.turn });
  });

  // Combat
  socket.on('attack-player', ({ targetPlayerId }) => {
    const game = games.get(socket.gameId);
    if (!game) return;

    const attacker = game.getPlayerState(socket.playerId);
    const defender = game.getPlayerState(targetPlayerId);

    if (!attacker || !defender) return;

    const combatResult = game.calculateCombat(attacker, defender);
    io.to(socket.gameId).emit('combat-resolved', {
      attacker: socket.playerId,
      defender: targetPlayerId,
      ...combatResult
    });
  });

  // Disconnect
  socket.on('disconnect', () => {
    console.log(`User disconnected: ${socket.id}`);
    const gameId = socket.gameId;
    const playerId = socket.playerId;
    
    if (gameId && playerId) {
      const game = games.get(gameId);
      if (game) {
        delete game.players[playerId];
        io.to(gameId).emit('player-left', { playerId });
      }
    }
  });
});

// Start server
const PORT = process.env.PORT || 5000;

const startServer = async () => {
  try {
    // Initialize database
    await initDatabase();
    console.log('Database initialized');
  } catch (err) {
    console.error('Failed to initialize database:', err);
  }

  server.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
};

startServer();

module.exports = { app, io, games };
